package airline_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;


class AirlineApplicationTests {

    @Test
    public void main() {
        String password;
        password = "root";
        assertEquals("root",password);
        String email;
        email = "admin";
        assertEquals("admin",email);
    }

}
