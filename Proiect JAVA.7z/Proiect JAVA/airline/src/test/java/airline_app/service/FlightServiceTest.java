package airline_app.service;

import airline_app.repository.FlightsRepository;
import airline_app.model.Flight;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;
import static org.skyscreamer.jsonassert.JSONAssert.assertEquals;

@ExtendWith(MockitoExtension.class)
public class FlightServiceTest {

    @Mock
    private FlightsRepository flightsRepository;

    @InjectMocks
    private FlightService flightService;

    @Test
    @DisplayName("Flight is created successfully")
    void  saveRFlight() {

        Flight flight = new Flight("003", "Bucuresti", "Sibiu", "11/03/2022", "12 AM", "14 AM", "Gate 13");
        when(flightsRepository.findById(flight.getId())).thenReturn(Optional.empty());

        Flight savedFlight = new Flight("003", "Bucuresti", "Sibiu", "11/03/2022", "12 AM", "14 AM", "Gate 13");
        when(flightsRepository.save(flight)).thenReturn(savedFlight);

        Flight result = flightService.saveFlight(flight);

       /* assertNotNull(result);
        assertEquals(savedFlight.getCod(), result.getCod());
        assertEquals(savedFlight.getStart(), result.getStart());
        assertEquals(savedFlight.getDestination(), result.getDestination());
        assertEquals(savedFlight.getDate(), result.getDate());
        assertEquals(savedFlight.getId()toString(),result.getId());
         */
    }



}

