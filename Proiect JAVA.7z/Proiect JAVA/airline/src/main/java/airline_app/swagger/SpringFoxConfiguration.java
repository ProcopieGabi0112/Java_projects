package airline_app.swagger;

import org.springframework.context.annotation.Bean;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2WebMvc;

import java.util.Collection;
import java.util.Collections;

@EnableSwagger2WebMvc
public class SpringFoxConfiguration {

    @Bean
    public Docket restAPI(ApiInfo apiInfo){
        return new Docket(DocumentationType.SWAGGER_2)
                .groupName("REST API(v1)")
                .select()
                .paths(PathSelectors.ant("/addFlight"))
                .build()
                .apiInfo(apiInfo());
    }

    private ApiInfo apiInfo() {
        return new ApiInfo(
                "SptingFox API Specification",
                "Spring REST APIs",
                "V01",
                "www.itasventure.org",
                new Contact("IT","www.itadventure.org","itadventure@gmail.com"),
                "Lincence of API",
                "www.itadventure.org",
                Collections.emptyList());


    }


}
