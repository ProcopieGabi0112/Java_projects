package airline_app.service;

import airline_app.model.Rating;

import java.util.List;

public interface RatingService {
    List<Rating> getAllRatings();
    Rating saveRating(Rating rating);
    Rating getRatingById(long id);
    void deleteRatingById(long id);
}
