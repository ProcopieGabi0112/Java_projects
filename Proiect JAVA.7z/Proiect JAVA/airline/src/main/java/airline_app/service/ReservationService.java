package airline_app.service;

import airline_app.model.Reservation;

import java.util.List;

public interface ReservationService {
    List<Reservation> getAllReservations();
    Reservation saveReservation(Reservation reservation);
    Reservation getReservationById(long id);
    void deleteReservationById(long id);
}
