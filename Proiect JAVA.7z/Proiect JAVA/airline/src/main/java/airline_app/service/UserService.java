package airline_app.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import airline_app.model.User;
import airline_app.web.dto.UserRegistrationDto;

public interface UserService extends UserDetailsService{
    User save(UserRegistrationDto registrationDto);
}
