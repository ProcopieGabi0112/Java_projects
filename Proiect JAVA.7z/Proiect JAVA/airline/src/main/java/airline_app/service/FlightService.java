package airline_app.service;

import airline_app.model.Flight;

import java.util.List;

public interface FlightService {

    List<Flight> getAllFlights();
    Flight saveFlight(Flight flight);
    Flight getFlightById(long id);
    void deleteFlightById(long id);
}
