package airline_app.service;

import airline_app.model.Flight;
import airline_app.repository.FlightsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FlightServiceImpl implements FlightService{

    @Autowired
    private FlightsRepository flightsRepository;

    @Override
    public List<Flight> getAllFlights() {
        return flightsRepository.findAll();
    }

    @Override
    public Flight saveFlight(Flight flight) {
        this.flightsRepository.save(flight);
        return flight;
    }

    @Override
    public Flight getFlightById(long id) {
        Optional<Flight> optional = flightsRepository.findById(id);
        Flight flight = null;
        if (optional.isPresent()) {
            flight = optional.get();
        }else{
        throw  new RuntimeException("Flight not found for id :: " + id);
        }
        return flight;
    }

    @Override
    public void deleteFlightById(long id) {
        this.flightsRepository.deleteById(id);

    }
}
