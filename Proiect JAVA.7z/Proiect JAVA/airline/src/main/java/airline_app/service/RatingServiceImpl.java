package airline_app.service;

import airline_app.model.Rating;
import airline_app.repository.RatingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RatingServiceImpl implements RatingService{

    @Autowired
    RatingRepository ratingRepository;

    @Override
    public List<Rating> getAllRatings() {
        return ratingRepository.findAll();
    }

    @Override
    public Rating saveRating(Rating rating) {
        this.ratingRepository.save(rating);
        return rating;
    }

    @Override
    public Rating getRatingById(long id) {
        Optional<Rating> optional = ratingRepository.findById(id);
        Rating rating = null;
        if (optional.isPresent()) {
            rating = optional.get();
        }else{
            throw  new RuntimeException("Rating not found for id :: " + id);
        }
        return rating;
    }

    @Override
    public void deleteRatingById(long id) {
        this.ratingRepository.deleteById(id);
    }
}
