package airline_app.service;

import airline_app.model.Location;

import java.util.List;

public interface LocationService {
    List<Location> getAllLocations();

}
