package airline_app.model;

import javax.persistence.*;

@Entity
@Table(name="Detalii")
public class PersonDetail {

    private int personDetailId;
    private String zipCode;
    private String job;
    private double income;

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name = "pDetail_FK")
    public int getPersonDetailId() {
        return personDetailId;
    }

    public void setPersonDetailId(int personDetailId) {
        this.personDetailId = personDetailId;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    public double getIncome() {
        return income;
    }

    public void setIncome(double income) {
        this.income = income;
    }
}
