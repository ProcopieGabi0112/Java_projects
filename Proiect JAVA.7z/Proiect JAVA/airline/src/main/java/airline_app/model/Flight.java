package airline_app.model;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "zboruri")
public class Flight {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private long id;

    @Column(name="cod")
    private String cod;

    @Column(name = "plecare")
    private String start;

    @Column(name="destinatie")
    private String destination;

    @Column(name="date")
    private String date;

    @Column(name="ora_plecarii")
    private String hour;

    public Flight(long id, String cod, String start, String destination, String date, String hour, String hour_arrivals, String gate, String status) {
        this.id = id;
        this.cod = cod;
        this.start = start;
        this.destination = destination;
        this.date = date;
        this.hour = hour;
        this.hour_arrivals = hour_arrivals;
        this.gate = gate;
        this.status = status;
    }
    public Flight(){

    }

    @Column(name="ora_sosiri")
    private String hour_arrivals;

    @Column(name="poarta_de_imbarcare")
    private String gate;

    public Flight(String s, String bucuresti, String sibiu, String s1, String s2, String s3, String s4) {

    }

    /*
    @OneToMany(targetEntity = Reservation.class,cascade=CascadeType.ALL)
    @JoinColumn(name = "cp_fk",referencedColumnName = "cod")
    private List<Reservation> reservations;

    public List<Reservation> getReservations() {
        return reservations;
    }

    public void setReservations(List<Reservation> reservations) {
        this.reservations = reservations;
    }
    */
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public String getStart() {
        return start;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public String getHour_arrivals() {
        return hour_arrivals;
    }

    public void setHour_arrivals(String hour_arrivals) {
        this.hour_arrivals = hour_arrivals;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Column(name="Status")
    private String status;


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCod() {
        return cod;
    }

    public void setCod(String cod) {
        this.cod = cod;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getHour() {
        return hour;
    }

    public void setHour(String hour) {
        this.hour = hour;
    }

    public String getGate() {
        return gate;
    }

    public void setGate(String gate) {
        this.gate = gate;
    }


}
