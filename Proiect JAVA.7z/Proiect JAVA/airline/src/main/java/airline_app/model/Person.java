package airline_app.model;

import javax.persistence.*;

@Entity
@Table(name="Client")
public class Person {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private int personId;
    private String personName;
    private String destination;
    private String comment;
    /*
       private PersonDetail personDetai
       @OneToOne(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
       @JoinColumn(name= "pDetail_FK")

    public PersonDetail getPersonDetail() {
        return personDetail;
    }

    public void setPersonDetail(PersonDetail personDetail) {
        this.personDetail = personDetail;
    }
*/
    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public int getPersonId() {
        return personId;
    }

    public void setPersonId(int personId) {
        this.personId = personId;
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }
}
