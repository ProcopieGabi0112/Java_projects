package airline_app.controller;

import airline_app.model.Reservation;
import airline_app.service.ReservationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class Rest_Reservation_Controller {

    @Autowired
    private ReservationService reservationService;

    @PostMapping("/addreservation")
    public Reservation saveReservation(@RequestBody Reservation reservation)
    {
        reservationService.saveReservation(reservation);
        return reservationService.saveReservation(reservation);
    }
    @GetMapping("/findAllReservation")
    public List<Reservation> getReservations(){
        return reservationService.getAllReservations();
    }

    @GetMapping("/findAllReservation/{id}")
    public Reservation getReservation(@PathVariable Long id){
        return reservationService.getReservationById(id);
    }

    @DeleteMapping("/deleteReservation/{id}")
    public String deteleReservation(@PathVariable long id){
        reservationService.deleteReservationById(id);
        return "Flight deleted with id:" + id;
    }


}