package airline_app.controller;

import airline_app.model.Rating;
import airline_app.repository.FlightsRepository;
import airline_app.service.RatingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class Rest_Rating_Controller {

    @Autowired
    private RatingService ratingService;

    @PostMapping("/addrating")
    public Rating saveRating(@RequestBody Rating rating)
    {
        ratingService.saveRating(rating);
        return ratingService.saveRating(rating);
    }
    @GetMapping("/findAllRatings")
    public List<Rating> getRatings(){
        return ratingService.getAllRatings();
    }

    @GetMapping("/findAllRatings/{id}")
    public Rating getRatings(@PathVariable Long id){
        return ratingService.getRatingById(id);
    }

    @DeleteMapping("/deleteRating/{id}")
    public String deteleRating(@PathVariable long id){
        ratingService.deleteRatingById(id);
        return "Rating deleted with id:" + id;
    }


}
