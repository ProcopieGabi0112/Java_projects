package airline_app.controller;

import airline_app.model.Flight;
import airline_app.repository.FlightsRepository;
import airline_app.service.FlightService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class Rest_Flight_Controller {

    @Autowired
    private FlightService flightService;

    @PostMapping("/addflight")
    public Flight saveRFlight(@RequestBody Flight flight)
    {
        flightService.saveFlight(flight);
        return flightService.saveFlight(flight);
    }
    @GetMapping("/findAllRFlights")
    public List<Flight> getRFlights(){
        return flightService.getAllFlights();
    }

    @GetMapping("/findAllRFlights/{id}")
    public Flight getRFlights(@PathVariable Long id){
        return flightService.getFlightById(id);
    }

    @DeleteMapping("/delete/{id}")
    public String deteleRFlight(@PathVariable long id){
        flightService.deleteFlightById(id);
        return "Flight deleted with id:" + id;
    }


}
