package airline_app.test;

import org.hamcrest.Matchers;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.springframework.test.web.client.match.MockRestRequestMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class ControllerTest {
    @Autowired
    private MockMvc mvc;

    /*@Test
    public  void get() throws Exception{
        mvc.perform((MockMvcRequestBuilders.get("/").accept(MediaType.APPLICATION_JSON))
                                                              .andExpect(status().isOk())
                                                              .andExpect(content().string(Matchers.equalTo("Eveything is alright")))));

    }*/

}
