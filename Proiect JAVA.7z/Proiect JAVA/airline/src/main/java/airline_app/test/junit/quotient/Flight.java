package airline_app.test.junit.quotient;

import lombok.SneakyThrows;

public class Flight {
    public int id;

    public Flight(String s, String bucuresti, String sibiu, String s1, String s2, String s3, String s4) {

    }

    @SneakyThrows
     public String testerror(String email, String password){
         if(email != "admin" && password != "root")
             throw new IllegalAccessException("User cant be accepted");

         return "User not found";
     }

}
