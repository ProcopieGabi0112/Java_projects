package airline_app.test;

import airline_app.model.Flight;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.ResponseEntity;

import static org.hamcrest.MatcherAssert.assertThat;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class Test_Controller {

    @Autowired
    private TestRestTemplate template;

    /*@Test
    public void get() throws Exception{
        ResponseEntity<Flight> response = template.getForEntity("/zboruri",Flight.class);
        assertThat(response.getBody()).isEqualTo("Everything is alright");
    }*/

    /*private <SELF> org.assertj.core.api.AbstractBigDecimalAssert<SELF> assertThat(Flight body) {
    }*/

}
