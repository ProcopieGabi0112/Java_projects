package airline_app.web.dto;

import airline_app.model.Flight;
import airline_app.model.Location;
import airline_app.model.Rating;
import airline_app.model.Reservation;
import airline_app.service.FlightService;
import airline_app.service.LocationService;
import airline_app.service.RatingService;
import airline_app.service.ReservationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class MainController {

    @Autowired
    private FlightService flightService;

    @Autowired
    private ReservationService reservationService;

    @Autowired
    private RatingService ratingService;

    @Autowired
    private LocationService locationService;


    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/")
    public String home() {
        return "index";
    }

    @GetMapping("/rezervari")
    public String viewHomPage(Model model){
        model.addAttribute("listReservation",reservationService.getAllReservations());
        return "rezervari";
    }

    @GetMapping("/showNewReservationForm")
    public String showNewReservationForm(Model model){
        Reservation reservation = new Reservation();
        model.addAttribute("reservation",reservation);
        return "new_reservation";
    }
    @PostMapping("/saveReservation")
    public String saveReservation(@ModelAttribute("reservation") Reservation reservation){
        reservationService.saveReservation(reservation);
        return "redirect:/rezervari";

    }
    @GetMapping("/showFormForUpdateReserv/{id}")
    public  String showFormForUpdateReserv(@PathVariable (value ="id") long id,Model model){
        Reservation reservation = reservationService.getReservationById(id);
        model.addAttribute("reservation",reservation);
        return "update_reservation";
    }

    @GetMapping("/deleteReservation/{id}")
    public  String deleteReservation(@PathVariable (value = "id") long id){
        this.reservationService.deleteReservationById(id);
        return "redirect:/rezervari";

    }

    @GetMapping("/locations")
    public String viewHPage(Model model){
        model.addAttribute("listLocations",locationService.getAllLocations());
        return "locations";
    }


    @GetMapping("/rating")
    public String viewHoPage(Model model){
        model.addAttribute("listRatings",ratingService.getAllRatings());
        return "rating";
    }

    @GetMapping("/showNewRatingForm")
    public String showNewRatingForm(Model model){
        Rating rating = new Rating();
        model.addAttribute("rating",rating);
        return "new_rating";
    }
    @PostMapping("/saveRating")
    public String saveRating(@ModelAttribute("rating") Rating rating) {
        ratingService.saveRating(rating);
        return "redirect:/rating";
    }


    @GetMapping("/zboruri")
    public String viewHomePage(Model model){
        model.addAttribute("listFlights",flightService.getAllFlights());
        return "zboruri";
    }

    @GetMapping("/showNewFlightForm")
    public String showNewFlightForm(Model model){
        Flight flight = new Flight();
        model.addAttribute("flight",flight);
        return "new_flight";
    }

    @PostMapping("/saveFlight")
    public String saveFlight(@ModelAttribute("flight") Flight flight){
        flightService.saveFlight(flight);
        return "redirect:/zboruri";

    }

    @GetMapping("/showFormForUpdate/{id}")
    public String showFormForUpdate(@PathVariable (value = "id") long id,Model model){

        Flight flight = flightService.getFlightById(id);
        model.addAttribute("flight",flight);
        return "update_flight";
    }
    @GetMapping("/deleteFlight/{id}")
    public String deleteFlight(@PathVariable (value = "id") long id){
        this.flightService.deleteFlightById(id);
        return "redirect:/zboruri";
    }

}
